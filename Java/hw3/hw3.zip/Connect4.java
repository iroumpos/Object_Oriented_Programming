package ce326.hw3;

public class Connect4 {
    

    public static void main(String[] args) {
        Connect4 cn4 = new Connect4();
    }

    public Connect4() {
        GUI gui = new GUI();
        gui.setVisible(true);
    }
}
