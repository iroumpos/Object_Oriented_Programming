---------------- Assignment 3 CONNECT4 -----------------

-> The replay of the game is not implemented
-> Sometimes problems with MinMax Algorithm

-> While playing as asked the AI plays first by default after pressing the NewGame with the wanted level. When the game is over because someone won, a new game is loaded with the default settings. If you want to change that and reload a new board press in the wanted settings such as new game and level of who plays first.

-----------------------------------------------------------
