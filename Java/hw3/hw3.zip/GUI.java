package ce326.hw3;


import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.text.html.HTMLDocument.RunElement;
import javax.xml.transform.stream.StreamResult;

import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyAdapter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.stream.Collectors;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


public class GUI extends JFrame implements ActionListener{
    
    public static int HEIGHT = 900;
    public static int WIDTH = 800;
    public int ROWS = 6;
    public int COLUMNS = 7;
    public int EMPTY = 0;
    public int AI = 1;
    public int PLAYER = 2;
    public int[][] gameBoard;
    int lastRow = -1;
    int lastCol = -1;
    int col_from_key = -1;
    int depth = -1;
    boolean isPlayerTurn = false;
    boolean endofgame = false;
    int whoWon = -1;    // 0: PLAYER WON ----- 1: AI WON
    MinMaxResult result = new MinMaxResult(-1, 1);
    public Timer timer_red;
    public Timer timer_yellow;
    public Color EMPTY_COLOR = Color.WHITE;
    public Color AI_COLOR = Color.YELLOW;
    public Color PLAYER_COLOR = Color.RED;
    int[][] recordMoves = new int[ROWS*COLUMNS][3];
    int movecount = 0;
    String level;
    String FILENAME = "game_record.xml";
    private static final String CONNECT4_DIRECTORY = "Connect4";


    public LocalDateTime startTime;
    
    JFrame frame;
    JPanel Mypanel;
    JPanel GamePanel;
    JMenuBar menuBar;
    JMenu Newgame,player,History,Help;
    JMenuItem Trivial,Medium,Hard;
    JRadioButtonMenuItem ai,you;
    JDialog modalBox;
    RoundButton[][] boardButtons;
    JList<String> hList;
    DefaultListModel<String> listModel;
    WindowListener dialogWindowListener;

    private static class MinMaxResult {
        public int column;
        public int value;

        public MinMaxResult(int column, int value) {
            this.column = column;
            this.value = value;
        }
    }


    public GUI() {
        this.setTitle("Connect4");
        this.setSize(HEIGHT, WIDTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                
        GamePanel = new JPanel(new GridLayout(ROWS, COLUMNS));
        GamePanel.setBackground(Color.BLUE);

        /*---------Create Connect4 grid--------- */
        gameBoard = new int[ROWS][COLUMNS];
        initBoard(gameBoard);
        boardButtons = new RoundButton[ROWS][COLUMNS];
        for(int i = 0; i < ROWS; i++) {
            for(int j = 0; j < COLUMNS; j++){
                boardButtons[i][j] = new RoundButton("");
                boardButtons[i][j].setEnabled(true);
                boardButtons[i][j].addActionListener(this);
                GamePanel.add(boardButtons[i][j]);
            }
        }

        // Add a KeyListener to the Connect4GUI class
        addKeyListener(new KeyAdapter() {
        	@Override
            public void keyPressed(KeyEvent e) {
        		int keyCode = e.getKeyCode();
        		if (keyCode >= KeyEvent.VK_0 && keyCode <= KeyEvent.VK_6) {
                    col_from_key = keyCode - KeyEvent.VK_0;
                    dropPiece(col_from_key, PLAYER);
                    //System.out.println("Dropping piece for player from keyboard!");
                    if(check_for_win(gameBoard,PLAYER)) {
                        whoWon = 0;
                        //printBoard(gameBoard);
                        recordGame(level, recordMoves);
                        clearRecordedMoves();
                        movecount = 0;
                        JOptionPane.showMessageDialog(GamePanel, "You won!");
                        JOptionPane.getRootFrame().addWindowListener(dialogWindowListener);
                        resetsBoards(gameBoard, boardButtons);
                        
                    }
                    result = AImove();
                    dropPiece(result.column, AI);
                    if(check_for_win(gameBoard,AI)) {
                        whoWon = 1;
                        //printBoard(gameBoard);
                        recordGame(level, recordMoves);
                        clearRecordedMoves();
                        movecount = 0;
                        JOptionPane.showMessageDialog(GamePanel, "You lost!");
                        JOptionPane.getRootFrame().addWindowListener(dialogWindowListener);
                        resetsBoards(gameBoard, boardButtons);
                    }
                }
            }
        });
        // Enable the Connect4GUI to receive key events
        setFocusable(true);
        

        /*--------Menu Options--------- */
        menuBar = new JMenuBar();
        Newgame = new JMenu("New Game");
        Trivial = new JMenuItem("Trivial");
        Medium = new JMenuItem("Medium");
        Hard = new JMenuItem("Hard");

        Trivial.addActionListener(this);
        Medium.addActionListener(this);
        Hard.addActionListener(this);

        
        player = new JMenu("1st Player");
        ButtonGroup group = new ButtonGroup();
        ai = new JRadioButtonMenuItem("AI");
        ai.addActionListener(this);
        group.add(ai);
        player.add(ai);
        you = new JRadioButtonMenuItem("You");
        you.addActionListener(this);
        group.add(you);
        player.add(you);

        History = new JMenu("History");
        // JMenuItem historyItem = new JMenuItem("View History");
        // historyItem.addActionListener(new ActionListener() {
        //     @Override
        //     public void actionPerformed(ActionEvent e) {
        //         System.out.println("I'm in history");
        //     }
        // });

        // History.add(historyItem);
        listModel = new DefaultListModel<>();
        hList = new JList<>(listModel);
        hList.setModel(listModel);
        hList.addListSelectionListener(new ListSelectionListener() {

            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                   // System.out.println("I'm in history");
                }
            }
            
        });
        JScrollPane pane = new JScrollPane(hList);
        
        History.add(pane);

        Help = new JMenu("Help");
        
        dialogWindowListener = new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                // Perform any desired action when the dialog is closed
                //System.out.println("Dialog closed");
            }
        };

        Newgame.add(Trivial);
        Newgame.add(Medium);
        Newgame.add(Hard);
        menuBar.add(Newgame);
        menuBar.add(player);
        menuBar.add(History);
        menuBar.add(Help);
        this.setJMenuBar(menuBar);
        this.add(GamePanel);
        GamePanel.setVisible(true);
        this.setVisible(true);
       
    }

    public void initBoard(int[][] board){
        for(int i=0; i < ROWS; i++) {
            for (int j=0; j < COLUMNS; j++) {
                board[i][j] = EMPTY;
            }
        }
    }

    public boolean setPiece(int[][] board, int row,int column, int type) {
        if (board[row][column] == EMPTY)
            return false;
        
        board[row][column] = type;
        lastRow = row;
        lastCol = column;
        return true;
    }

    public int[][] getBoard() {
        return gameBoard;
    }

    public JButton[][] getBoardButtons() {
        return boardButtons;
    }

    private int check_column(JButton button) {
        for (int i=0; i < ROWS; i++) {
            for (int j=0; j < COLUMNS; j++) {
                if (boardButtons[i][j] == button) {
                    //System.out.println("Row: "+i+" Column: "+j);
                    return j;
                }   
            }
        }
        return -1;
    }

    private int check_row(int col) {
        if (col == -1)
            return -1;
        for (int i = ROWS - 1; i >= 0; i--) {
            if(gameBoard[i][col] == EMPTY)
                return i;
        }
        return -1;
    }

    public void dropPiece(int column,int type) {
        int row = check_row(column);
        if (column != -1 && row != -1) {
            if (type == AI) {
                gameBoard[row][column] = AI;
                boardButtons[row][column].setBackground(AI_COLOR);
                recordMoves[movecount][0] = row;
                recordMoves[movecount][1] = column;
                recordMoves[movecount][2] = AI;
                movecount++;  
            }
            else if (type == PLAYER) {
                //System.out.println("Dropping piece for player!");
                gameBoard[row][column] = PLAYER;
                boardButtons[row][column].setBackground(PLAYER_COLOR);
                recordMoves[movecount][0] = row;
                recordMoves[movecount][1] = column;
                recordMoves[movecount][2] = PLAYER;
                movecount++;
            }
        }
    }

    public MinMaxResult AImove(){
        return MinMax(gameBoard, depth, -Integer.MAX_VALUE, Integer.MAX_VALUE, true);
    }

    public void resetsBoards(int[][] board,RoundButton[][] gui) {
        for (int i = 0; i < ROWS; i++){
            for (int j = 0; j < COLUMNS; j++) {
                board[i][j] = EMPTY;
                gui[i][j].setBackground(Color.WHITE);
            }
        }
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            // TODO: handle exception
        }
    }

    public void recordGame(String level, int[][] moves) {
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.newDocument();

            // Create root element
            Element rootElement = doc.createElement("game");
            doc.appendChild(rootElement);

            // Add level information
            Element levelElement = doc.createElement("level");
            levelElement.appendChild(doc.createTextNode(level));
            rootElement.appendChild(levelElement);

            // Add start time information
            Element startTimeElement = doc.createElement("start_time");
            LocalDateTime startTime = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            startTimeElement.appendChild(doc.createTextNode(startTime.format(formatter)));
            rootElement.appendChild(startTimeElement);

            // Add moves information
            Element movesElement = doc.createElement("moves");
            rootElement.appendChild(movesElement);

            for (int[] move : moves) {
                Element moveElement = doc.createElement("move");
                moveElement.setAttribute("row", String.valueOf(move[0]));
                moveElement.setAttribute("column", String.valueOf(move[1]));
                moveElement.setAttribute("type", move[2] == AI ? "AI" : "PLAYER");
                movesElement.appendChild(moveElement);
            }

            // Transform the document to XML file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            String userhome = System.getProperty("user.home");
            String Connect4path = userhome + File.separator + CONNECT4_DIRECTORY;
            File directory = new File(Connect4path);
            if(!directory.exists())
                directory.mkdirs();
            
            String filename = "game_record_";
            filename += startTime.format(formatter);
            filename += ".xml";
            String filepath = filename + File.separator + filename;
            StreamResult result = new StreamResult(new File(filepath));
            transformer.transform(source, result);

            System.out.println("Game recorded successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String HistoryEntry(){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy.MM.dd - HH:mm");
        startTime = LocalDateTime.now();
        String result = startTime.format(formatter);
        result += "  L: " + level;
        if (whoWon == 0)
            result += " W: P";
        if (whoWon == 1)
            result += " W: AI";
        return result;
    }

    public void replayGame() {
        resetsBoards(gameBoard, boardButtons);
        //System.out.println("Im in replay game!");
        for (int i=0; i < movecount; i++) {
            int row = recordMoves[i][0];
            int column = recordMoves[i][1];
            int type = recordMoves[i][2];
            if (type == AI)
                boardButtons[row][column].setBackground(AI_COLOR);
            if(type == PLAYER)
                boardButtons[row][column].setBackground(PLAYER_COLOR);
            
        }
    }

    public void clearRecordedMoves() {
        for(int i=0; i < movecount; i++) {
            recordMoves[i][0] = -1;
            recordMoves[i][1] = -1;
            recordMoves[i][2] = -1;
        }
    }
    
    //---------------------------- LOGIC CONNECT 4 -------------------------------------
    

    public  int addtoBoard(int[][] board,int place,int type) {
        for (int i=0; i < ROWS; i++) {
            if (board[ROWS-1-i][place] == EMPTY) {
                board[ROWS-1-i][place] = type;
                return i;
            }
        }
        return -1;
    }

    

    public  int evaluate(List<Integer> window, int type) {
        int score = 0;
        int opp_score = PLAYER;
        if (type == PLAYER)
            opp_score = AI;
        
        if (Collections.frequency(window,type) == 4)
            score += 10000;
        if (Collections.frequency(window, type) == 3 && Collections.frequency(window, EMPTY) == 1)
            score += 16;
        if (Collections.frequency(window, type) == 2 && Collections.frequency(window, EMPTY) == 2){
            score += 4;
        }
        if (Collections.frequency(window, type) == 1 && Collections.frequency(window, EMPTY) == 3){
            score += 1;
        }
        
        // if (Collections.frequency(window,opp_score) == 4)
        //     score -= 10000;
        // if (Collections.frequency(window, opp_score) == 3 && Collections.frequency(window, EMPTY) == 1)
        //     score -= 16;
        // if (Collections.frequency(window, opp_score) == 2 && Collections.frequency(window, EMPTY) == 2)
        //     score -= 4;
        // if (Collections.frequency(window, opp_score) == 1 && Collections.frequency(window, EMPTY) == 3)
        //     score -= 1;
        
        
        return score;
    }

    public  int score_calc(int[][] board,int type) {
        int score = 0;

        // Check Horizontal
        for (int i=0; i < ROWS; i++) {
            int ROWS_array[] = new int[COLUMNS];
            for (int j = 0; j < COLUMNS; j++) {
                ROWS_array[j] = board[i][j];
            }
            for (int k = 0; k < COLUMNS - 3; k++) {
                int[] window_arr = Arrays.copyOfRange(ROWS_array,k,k+4);
                List<Integer> window = Arrays.stream(window_arr).boxed().collect(Collectors.toList());
                score += evaluate(window,type);
            }
        }
        
        // Check Vertical
        for (int i=0; i < COLUMNS; i++) {
            int column_array[] = new int[ROWS];
            for (int j=0; j < ROWS; j++) {
                column_array[j] = board[j][i];
            }
            for (int k=0; k < ROWS - 3; k++) {
                int[] window_arr = Arrays.copyOfRange(column_array, k, k+4);
                List<Integer> window = Arrays.stream(window_arr).boxed().collect(Collectors.toList());
                score += evaluate(window, type);
            }
        }
       
        // Check upper diagonal
        for (int i = 0; i < ROWS - 3; i++) {
            for (int j = 0; j < COLUMNS - 3; j++) {
                int[] window_arr = new int[4];
                for (int k = 0; k < 4; k++) {
                    window_arr[k] = board[i+k][j+k];
                }
                List<Integer> window = Arrays.stream(window_arr).boxed().collect(Collectors.toList());
                score += evaluate(window, type);
            }
        }
        
        // Check lower diagonal
        for (int i = 0; i < ROWS - 3; i++) {
            for (int j = 0; j < COLUMNS - 3; j++) {
                int[] window_arr = new int[4];
                for (int k = 0; k < 4; k++) {
                    window_arr[k] = board[i+3-k][j+k];
                }
                List<Integer> window = Arrays.stream(window_arr).boxed().collect(Collectors.toList());
                score += evaluate(window, type);
            }
        }
        // System.out.println("Score is: "+score);
        return score;
    }

    public boolean check_for_win(int[][] board,int type) {
        // Horizontal check
        for (int i=0; i < COLUMNS-3; i++) {
            for (int j=0; j < ROWS; j++) {
                if (board[j][i] == type && board[j][i+1] == type && board[j][i+2] == type && board[j][i+3] == type)
                    return true; 
            }
        }

        // Vertical check
        for (int i=0; i < COLUMNS; i++) {
            for (int j=0; j < ROWS - 3; j++) {
                if (board[j][i] == type && board[j+1][i] == type && board[j+2][i] == type && board[j+3][i] == type)
                    return true;
            }
        }

        // Upper diagonal
        for (int i=0; i<COLUMNS-3; i++) {
            for(int j=0; j < ROWS-3; j++) {
                if (board[j][i] == type && board[j+1][i+1] == type && board[j+2][i+2] == type && board[j+3][i+3] == type)
                    return true;
            }
        }

        // Lower diagonal
        for (int i=0; i < COLUMNS-3; i++) {
            for (int j = 3; j < ROWS; j++) {
                if (board[j][i] == type && board[j-1][i+1] == type && board[j-2][i+2] == type && board[j-3][i+3] == type)
                    return true;
            }
        }
        return false;
    }

    public int next_row_available(int[][] board,int col) {
        for (int i = 0; i < ROWS; i++) {
            if (board[i][col] == EMPTY)
                return i;
        }
        return -1; // not available
    }

    public List<Integer> valid_cols(int[][] board) {
        List<Integer> list = new ArrayList<>();
        for (int i=0; i < COLUMNS; i++) {
            if (board[0][i] == EMPTY)
                list.add(i);
        }
        return list;
    } 
    
    public boolean is_terminal(int[][] board) {
        return check_for_win(board,AI) || check_for_win(board,PLAYER);
    }

    public int[][] copy_board(int[][] board) {
        int[][] b_copy = new int[ROWS][COLUMNS];
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLUMNS; j++) {
                b_copy[i][j] = board[i][j];
            }
        }
        return b_copy;
    }
    

    public MinMaxResult MinMax(int[][] board,int depth,int alpha,int beta,boolean isMax){
        MinMaxResult output = new MinMaxResult(-1, 0);
        List<Integer> locations = valid_cols(board);
        boolean terminal = is_terminal(board);
        // System.out.println("Depth is: "+depth);
        if (depth == 0 || terminal == true) {
            if (terminal == true) {
                if (check_for_win(board,AI)) {
                    output.column = -1;
                    output.value = 1000000000;
                    return output;
                } else if (check_for_win(board,PLAYER)) {
                    output.column = -1;
                    output.value = -1000000000;
                    return output;
                }
                else {
                    output.column = -1;
                    output.value = 0;
                    return output;
                }
            } else {
             /* Depth is 0 */
                // System.out.println("Im in depth zero");
                output.column = -1;
                output.value = score_calc(board, AI);
                return output;
            }
            
        }

        if (isMax == true) {
            //result[0] = locations.get(random.nextInt(locations.size()));
            //int column;
            output.value = -Integer.MAX_VALUE;
            /*if(locations.size() > 0)
                column = locations.get((int)(Math.random() * locations.size()));
            else
                column = 0;*/
            for(Integer col : locations) {
                int row = next_row_available(board, col);
                int board_copy[][] = copy_board(board);
                board_copy[row][col] = AI;
                int new_score = MinMax(board_copy, depth - 1, alpha, beta, false).value;
                //System.out.println(temp);
                if (new_score > output.value) {
                        output.value = new_score;
                        output.column = col;
                }
                
                alpha = Math.max(alpha,output.value);
                if (alpha >= beta)
                    break;
            }
            return output;
        } else {
            //int column;
            output.value = Integer.MAX_VALUE;
            /*if(locations.size() > 0)
                column = locations.get((int)(Math.random() * locations.size()));
            else
                column = 0;*/
            for(Integer col : locations) {
                int row = next_row_available(board, col);
                int board_copy[][] = copy_board(board);
                board_copy[row][col] = PLAYER;
                int new_score = MinMax(board_copy, depth - 1, alpha, beta, true).value;
            
                 if (new_score < output.value) {
                    output.value = new_score;
                    output.column = col;
                }   
                
                beta = Math.min(beta,output.value);
                if (alpha >= beta)
                    break;
            }
            return output;
        }
        
    }

    public void printBoard(int[][] board){
        System.out.println(" ------ AI ------");
        System.out.println("-----------------------------");
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLUMNS; j++){
                if(board[i][j] == EMPTY)
                    System.out.print("|   ");
                if(board[i][j] == AI)
                    System.out.print("| O ");
                if(board[i][j] == PLAYER)
                    System.out.print("| X ");
            }
            System.out.println("|");
            //System.out.println("|   |   |   |   |   |   |   |");
            System.out.println("-----------------------------");
        }
        System.out.println();
        System.out.println("| 0 | 1 | 2 | 3 | 4 | 5 | 6 |");  
    }

    //----------------------------------------------------------------------------------------------------


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == ai) {
            isPlayerTurn = false;
        }

        if (e.getSource() == you) {
            System.out.println("My turn!");
            isPlayerTurn = true;
            resetsBoards(gameBoard, boardButtons);
        }

        if (e.getSource() == Trivial) {
            level = "Trivial";
            depth = 1;
            resetsBoards(gameBoard,boardButtons);
            if (isPlayerTurn == false && endofgame == false) {
                resetsBoards(gameBoard,boardButtons);
                gameBoard[5][3] = AI;
                boardButtons[5][3].setBackground(Color.YELLOW);
            }
        }
        if (e.getSource() == Medium) {
            level = "Medium";
            depth = 3;
            resetsBoards(gameBoard,boardButtons);
            if (isPlayerTurn == false && endofgame == false) {
                resetsBoards(gameBoard,boardButtons);
                gameBoard[5][3] = AI;
                boardButtons[5][3].setBackground(Color.YELLOW);
                
            }
        }

        if (e.getSource() == Hard) {
            level = "Hard";
            depth = 5;
            resetsBoards(gameBoard,boardButtons);
            if (isPlayerTurn == false && endofgame == false) {
                resetsBoards(gameBoard,boardButtons);
                gameBoard[5][3] = AI;
                boardButtons[5][3].setBackground(Color.YELLOW);
                
            }
        }
        
        if (e.getSource() == History) {
            System.out.println("I pressed history!");
            //recordGame(level, recordMoves);
            resetsBoards(gameBoard, boardButtons);
            replayGame();
        }

        JButton button = (JButton) e.getSource();

        int col = check_column(button); 
        int row = check_row(col);
        

        if (col != -1) {
            if (row == -1) {
                System.out.println("Column is full");
                System.exit(42);
            }

            if (gameBoard[row][col] == EMPTY) {
                dropPiece(col,PLAYER);
                //printBoard(gameBoard);
                if(check_for_win(gameBoard,PLAYER)) {
                    whoWon = 0;
                    recordGame(level, recordMoves);
                    String entry = HistoryEntry();
                    listModel.addElement(entry);
                    //printBoard(gameBoard);
                    JOptionPane.showMessageDialog(GamePanel, "You won!");
                    endofgame = true; 
                    resetsBoards(gameBoard, boardButtons);
                    //replayGame();
                    clearRecordedMoves();
                    movecount = 0;
                }
                
                
                
                    result = AImove();
                    dropPiece(result.column, AI);
                    // System.out.println("After MinMax is called column: "+result.column+" : "+result.value);
                    //printBoard(gameBoard);
                    if(check_for_win(gameBoard,AI)) {
                        // boardButtons[check_row(result.column)][result.column].setBackground(AI_COLOR);
                        whoWon = 1;
                        String entry = HistoryEntry();
                        listModel.addElement(entry);
                        //printBoard(gameBoard);
                        JOptionPane.showMessageDialog(GamePanel, "You lost!");
                        resetsBoards(gameBoard, boardButtons);
                        recordGame(level, recordMoves);
                        clearRecordedMoves();
                        movecount = 0;
                    }
                
            }
        }
    }


  
}
