---------------- Assignment 3 CONNECT4 -----------------

-- After the end of a game if the user wants to choose
    a new game should choose and the level of the ai.

-----------------------------------------------------------
