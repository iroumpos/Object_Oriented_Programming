package ce326.hw2;

// Only for a leaf node.

public class TreeNode {
    
    private double value;

    // default constructor
    public TreeNode(){}

    // new constructor
    public TreeNode(double value) {
        value = this.value;
    }

    public double getValue () {
        return value;
    }
}
